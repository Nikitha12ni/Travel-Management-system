<html>
    <body>
        <tr>
            <th>
                username
            </th>
        </tr>
        <?php
        $conn=mysqli_connect('localhost','root','','databse')
        $sql=select * from ;
        $result=$conn->query($sql)
        if($result->num_rows>0)
        {
         while(row-$result-> fetch_assoc())
         {
             echo "<tr><td>".$row["user_id"]."</td><td>.$row["userid"]."</td><td>.$row["userid"]."</td><td>.$row["userid"]."</td><td>.$row["userid"]."</td><td>.$row["userid"]
         }
        }
        else
        {
          echo  "there is no result";
    </body>
</html>