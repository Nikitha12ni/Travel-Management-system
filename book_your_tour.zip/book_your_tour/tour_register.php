<?php
 $fname = $_POST['fname'];
 $lname = $_POST['lname'];
$email = $_POST['email'];
$pass= $_POST['pass'];
$num=$_POST['num'];
$gender=$_POST['gender'];
$servername='localhost';
$username='root';
$password='';
$databasename = "book_your_tour";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if($conn->connect_error)  
{
die("connection failed:".$conn->connect_error);
}
else
{    
$stmt=$conn->prepare("insert into register(fname,lname,email,pass,num,gender)values(?,?,?,?,?,?)");
$stmt->bind_param("ssssis",$fname,$lname,$email,$pass,$num,$gender);
$s

?>
<!DOCTYPE html>

<html>

<head>
<title>Simple Registration Form</title>
<link rel="stylesheet" href="tour.css"type="text/css">

</head>

<body>

<div class="simple-form">

<form id="registration">

<input type="text" name="fname" id="button" placeholder="Enter your First Name"><br>

<br>
<input type="text" name="lname" id="button" placeholder="Enter your Last Name"><br><br>

<input type="email" name="email" id="button" placeholder="Enter your Email Id"><br><br>

<input type="password" name="pass" id="button" placeholder="Enter your Password"> <br>

<br>


<input type="number" name="num" placeholder="Enter your Mobile Number" id="ph"><br><br>

<input type="radio" name="gender" value="m" id="rd"><span id="but">Male</span><input type="radio"
name="gender" value="f" id="rd"><span id="but">Female</span><br><br>
<input type="submit"value="register"id="butt">
</form>

</div>

</body>
</html>
