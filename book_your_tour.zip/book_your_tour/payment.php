<?php
 session_start();
         $servername='localhost';
         $username='root';
         $password='';
         $databasename="rash";
         $conn=mysqli_connect($servername,$username,$password,$databasename);
         
         $dest=$_GET['destinsation'];
if(!$conn)  
{
     die("connection failed:".mysqli_connect_error());
}

if(isset($_POST['sendbtn']))
{    
     //$destinsation = $_POST['destinsation '];
    
     $Username= $_POST['Username'];
     $firstname = $_POST['firstname'];
    $nickname= $_POST['nicknmae'];
    $dof=$_POST['dof'];
    $gender=$_POST['gender'];
    $cardno=$_POST['cardno'];
    $cvc=$_POST['cvc'];
     $sql_query ="insert into book(destinsation,USERNAME,firstname,nickname,dof,gender,CARDNO,CVC)values('$dest' ,'$Username','$firstname','$nickname','$dof','$gender','$cardno','$cvc')";
     if(mysqli_query($conn, $sql_query))
      {
        echo "Your booked successfully !";
     }
      else 
      {
        echo "Error: " . $sql . ":" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="paymentform.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<style>
    *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body{
    background-color: #f5f5f5;
    font-family: Arial, Helvetica, sans-serif;
}
.wrapper{
    background-color: #ffff;
    width: 500px;
    heiheight: 500px;;
    padding: 25px;
    margin: 25px auto 0;
    box-shadow: 0px 0px 20px rgba(0,0,0,0.5);
}
.wrapper h2{
    background-color: #fcfcfc;
    color: #7ed321;
    font-size: 24px;
    padding: 10px;
    margin-bottom: 20px;
    text-align: center;
    border: 1px dotted #333;
}
h4{
    padding-bottom: 5px;
    color: #7ed321;
}
.input-group{
    margin-bottom: 8px;
    width: 100%;
    position: relative;
    display: flex;
    flex-direction: row;
    padding: 5px 0;
}
.input-box{
    width: 100%;
    margin-right: 12px;
    position: relative;
}
.input-box:last-child{
    margin-right: 0;
}
.name{
    padding: 14px 10px 14px 50px;
    width: 100%;
    background-color: #fcfcfc;
    border: 1px solid #00000033;
    outline: none;
    letter-spacing: 1px;
    transition: 0.3s;
    border-radius: 3px;
    color: #333;
}
.name:focus, .dob:focus{
    -webkit-box-shadow:0 0 2px 1px #7ed32180;
    -moz-box-shadow:0 0 2px 1px #7ed32180;
    box-shadow: 0 0 2px 1px #7ed32180;
    border: 1px solid #7ed321;
}
.input-box .icon{
    width: 48px;
    display: flex;
    justify-content: center;
    align-items: center;
    position: absolute;
    top: 0px;
    left: 0px;
    bottom: 0px;
    color: #333;
    background-color: #f1f1f1;
    border-radius: 2px 0 0 2px;
    transition: 0.3s;
    font-size: 20px;
    pointer-events: none;
    border: 1px solid #00000033;
    border-right: none;
}
.name:focus + .icon{
    background-color: #7ed321;
    color: #fff;
    border-right: 1px solid #7ed321;
    border: none;
    transition: 1s;
}
.dob{
    width: 30%;
    padding: 14px;
    text-align: center;
    background-color: #fcfcfc;
    transition: 0.3s;
    outline: none;
    border: 1px solid #c0bfbf;
    border-radius: 3px;
}
.radio{
    display: none;
}
.input-box label{
    width: 50%;
    padding: 13px;
    background-color: #fcfcfc;
    display: inline-block;
    float: left;
    text-align: center;
    border: 1px solid #c0bfbf;
}
.input-box label:first-of-type{
    border-top-left-radius: 3px;
    border-bottom-left-radius: 3px;
    border-right: none;
}
.input-box label:last-of-type{
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
}
.radio:checked + label{
    background-color: #7ed321;
    color: #fff;
    transition: 0.5s;
}
.input-box select{
    display: inline-block;
    width: 50%;
    padding: 12px;
    background-color: #fcfcfc;
    float: left;
    text-align: center;
    font-size: 16px;
    outline: none;
    border: 1px solid #c0bfbf;
    cursor: pointer;
    transition: all 0.2s ease;
}
.input-box select:focus{
    background-color: #7ed321;
    color: #fff;
    text-align: center;
}
button{
    width: 100%;
    background: transparent;
    border: none;
    background: #7ed321;
    color: #fff;
    padding: 15px;
    border-radius: 4px;
    font-size: 16px;
    transition: all 0.35s ease;
}
button:hover{
    cursor: pointer;
    background: #5eb105;
}
</style>
    </head>
<body>
    
<div class="input-box">
                   <a href="userview.php"> <button  >CANCEL</button></a>
                </div>

    <div class="wrapper">
        <h2>
Payment Form</h2>
<form  action="userview.php" method="POST">
            <h4>
Account</h4>
<div class="input-group">
                <div class="input-box">
                    <input name="firstname" type="text" placeholder="Full Name" required class="name">
                    <i class="fa fa-user icon"></i>
                </div>
<div class="input-box">
                    <input name="nickname" type="text" placeholder="Nick Name" required class="name">
                    <i class="fa fa-user icon"></i>
                </div>
</div>
<div class="input-group">
                <div class="input-box">
                    <input name="Username" type="email" placeholder="Email Adress" required class="name">
                    <i class="fa fa-envelope icon"></i>
                </div>
</div>

<div class="input-group">
                <div class="input-box">
                    <input name="gender" type="text " placeholder="gender" required class="name">
                    <i class="fa fa-envelope icon"></i>
                </div>
</div>
<div class="input-group">
                <div class="input-box">
                    <input name="dof" type="text" placeholder="Enter the date of birth" required class="name">
                    <i class="fa fa-envelope icon"></i>
                </div>
</div> 

<div class="input-group">
                <div class="input-box">
                    <h4>
Payment Details</h4>
<input  type="radio" name="pay" id="bc1" checked class="radio">
                    <label for="bc1"><span><i class="fa fa-cc-visa"></i> Credit Card</span></label>
                    
                    
                </div>
</div>
<div class="input-group">
                <div class="input-box">
                    <input  name="cardno" type="tel" placeholder="Card Number" required class="name">
                    <i class="fa fa-credit-card icon"></i>
                </div>
</div>
<div class="input-group">
                <div class="input-box">
                    <input name="cvc" type="tel" placeholder="Card CVC" required class="name">
                    <i class="fa fa-user icon"></i>
                 </div>

            
</div>
<div class="input-group">
                <div class="input-box">
                    <button name="sendbtn" type="submit">PAY NOW</button>
                </div>
</div>
</div>

</form>
</div>
</body>
</html>
