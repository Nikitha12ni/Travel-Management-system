
     <?php
         $servername='localhost';
         $username='root';
         $password='';
         $databasename="rash";
         $conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
     die("connection failed:".mysqli_connect_error());
}
if(isset($_POST['sendbtn']))
{    
     $name = $_POST['name'];
     $email = $_POST['email'];
     $phone_no = $_POST['phone_no'];
     $password= $_POST['password'];
     $sql_query ="insert into signup(NAME,EMAIL,PHONE_NUMBER,PASSWORD)values('$name','$email','$phone_no','$password')";
     if(mysqli_query($conn, $sql_query))
      {
        echo "New record has been added successfully !";
        
     }
      else 
      {
        echo "Error: " . $sql . ":" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>
<!DOCTYPE html>

     <html>
<head>
     
<link rel="stylesheet"  href="aregister.css">
<title>
signup
</title>

</head>
<body>
     <div  class="banner-area">
<form  method="post" action="coonect.php" class="submission_form">
<label for="name">
Name
</label>

<input type="text" name="name">
<br><br>
<label for="email">
Email
</label>
<input type="text" name="email"><br><br>
<label for="phone_no">
Phone Number
</label>


<input type="tel" name="phone_no"><br><br>
<label for="password">
Password
</label>

<input type="text" name="password"><br><br>
<input type="submit" value="Send" name="sendbtn">
</form>
</div>
</body>
</html>

