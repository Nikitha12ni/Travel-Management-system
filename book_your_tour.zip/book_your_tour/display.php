<?php

include 'admin_entry.php';
$selectquery = "select name,destinsation,noofdays,price from admin_entry";
$query = mysqli_query($conn,$selectquery);
$nums = mysqli_num_rows($query);
$res = mysqli_fetch_array($query);
while($i<10){
    
}
?>