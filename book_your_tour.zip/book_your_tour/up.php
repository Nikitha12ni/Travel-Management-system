<?php
mysql_connect( "localhost","root","");
mysql_query("rash");
$name=$_GET['a'];
mysql_query("");
?>
<table border=1>
    <?php while($r =mysql_fetch_array($s))
    {
        ?>
        <tr>

            <td><?php echo $r['name']; ?></td>
    </tr>
    <tr>

            <td><?php echo $r['destinsation']; ?></td>
    </tr>
    <tr>

            <td><?php echo $r['noofdays']; ?></td></tr>
            <tr>

            <td><?php echo $r['price']; ?></td></tr>
            <td><input type="submit " name="s" value="change now"< /td>

        </tr>
        <?php   } ?></table>