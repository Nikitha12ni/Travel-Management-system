<?php

$nm = $_GET['a'];
mysql_connect("localhost","root",'');
mysql_select_db("project");
mysql_query("delete from admin_entry where name='$nm'");
header("locationLtable.php");
?>