<?php
session_start();
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'rash');
if(isset($_POST['login']))
{
    $Email_id= $_POST['username'];
    $Password = $_POST['password'];
    $sql=mysqli_query($con,"SELECT * FROM userinfo where EMAIL='$Email_id' and  PASSWORD='$Password'");
    $row  = mysqli_fetch_array($sql);
    if(is_array($row))
    {
        
        $_SESSION["Email"]=$row['Email_id'];
        
        
        header("Location:userview.php"); 
    }
    else
    {
         echo "  <script>alert('Invalid login details')</script>";
       
        header("Location:user_login.php"); 
    }
}
?>


<html>
 <head>
     <style> 
          h1{
              color: black;
              font-family: "Times New Roman", Times, serif;
          }
          h3{
               color: black;
               line-height: 0.1;
               font-family: Copperplate, Papyrus, fantasy;
                     
             }
          
                .center{
                    background-color:rgb(142, 202, 226);
                    opacity: 0.8;
                    margin: auto;
                    width : 25%;
                    border: 1px solid black;
                    padding: 10px;
                }
                
            form{
                text-align: center;
                }  
                body {
                       background-image: url("pexels-photo-386000.jpeg");
                       background-color: #337792;
                       height: 300px;
                       
                       
                       background-repeat: no-repeat;
                       background-size: cover;
                    }


              
.center .h2
{
    color:#dabc6a;
}

         </style>
     <title>login page</title>
 </head>
 <body>
     <br>
    
     
     <form  method="post" action="userview.php" class="center">
        <h2> User Login</h2>
        <label for="username"> Username: </label>
        <input type="text" id="username" name="username" placeholder="username" required>
        <br><br>
        <label for="password"> Password: </label>
        <input type="password" id="password" name="password"  password="password" placeholder="password" required>
        <br><br>
       
       
        <br><br>
        <input  type="submit" value="login">
        <BR>
        <a href="USERREGISTER.php"> REGISTER</a>

     </form>

    </body>

</html>