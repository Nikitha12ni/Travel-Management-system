<?php
mysql_connect("localhost","root","");
mysql_select_db("rash");
$s = mysql_query("select name,destinsation,noofdays,price from admin entry");
?>
<table border=1>
    <tr>
        <th>
            Name
        </th>
        <th>
            Destination
        </th>
        <th>no of days</th>
        <th>price</th>
        <th>
            Delete
        </th>
        <th>update</th>
    </tr>
    <?php while($r =mysql_fetch_array($s))
    {
        ?>
        <tr>

            <td><?php echo $r['name']; ?></td>
            <td><?php echo $r['destinsation']; ?></td>
            <td><?php echo $r['noofdays']; ?></td>
            <td><?php echo $r['price']; ?></td>
            <td><a href="del.php?a=<?php echo $r['name'];?>"Remove</a></a></td>
<td><a href="up.php?a=<?php echo $r['name'];?>" change</td>
        </tr>
        <?php   } ?>
    </table>