<?php
         $servername='localhost';
         $username='root';
         $password='';
         $databasename = "rash";
         $conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
     die("connection failed:".mysqli_connect_error());
}
if(isset($_POST['sendbtn']))
{    
     $name = $_POST['name'];
     $email = $_POST['email'];
     $destination = $_POST['destination'];
     $no_of_days = $_POST['no_of_days'];
     $prize =$_POST['$prize'];
     $sql_query ="insert into admin_entry(name,Username,destinsation,noofdays,price)values('$name','$email','$destination','$no_of_days','$prize')";
     if(mysqli_query($conn, $sql_query))
      {
        echo "New record has been added successfully !";
     }
      else 
      {
        echo "Error: " . $sql . ":" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>
<!DOCTYPE html>

     <html>
<head>
     
<link rel="stylesheet"  href="aregister.css">
<title>
signup
</title>

</head>
<body>
     <div  class="banner-area">
<form  method="post" action="ad.php" class="submission_form">
<label for="name">
Travel agency name
</label>

<input type="text" name="name">
<br><br>
<label for="email">
Username
</label>
<input type="text" name="email"><br><br>
<label for="name">
Destination
</label>

<input type="text" name="destination">
<br><br>
<label for="name">
No of days
</label>

<input type="text" name="no_of_days">
<br><br>
<label for="name">
Prize
</label>

<input type="text" name="prize">
<br><br>
<input type="submit" value="Send" name="sendbtn">
</form>
</div>
</body>
</html>

