<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "rash";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html>
    <head>
    
        <title>Userview </title>
        <?php include 'links.php' ;?>
        <link rel="stylesheet" href="style.css">
        <style>
        .ad{
            
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       font-size: 150%;
                       background-color: black;
                       
  
  padding: 10px 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
}
        </style>
      
    <body>
   <div class ="ad"> <a href="admin.html" target="_blank">BACK</a></div>
        <div class="main-div">
            
            <h1>lists</h1>
            <div  class="center-div">
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>travel agency name</th>
                                <th>destination</th>
                                <th>no of days</th>
                                <th>price</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                       <?php
                         $selectquery="select name,destinsation ,noofdays,price from admin_entry ";
                         $query=mysqli_query($conn,$selectquery);
                         $nums=mysqli_num_rows($query);

                         

                       
                            
                             while($res= mysqli_fetch_array($query))
                         {
                            <tr>
                            <td><?php echo $res['name'];?></td>
                            <td><?php echo $res['destinsation'];?></td>
                            <td><?php echo $res['noofdays'];?></td>
                            <td><?php echo $res['price'];?></td>
                            
                            
                            <td><button><a href="delete.php?name=<?php echo $res['name'];?>">delete</a></button></i></td>
                                             
                           </tr>
                        
                         }
                        ?>
                        </tbody>
                    </table>


                </div>
            </div>
        </div>
        
    </body>
    <script>
$(document).ready(function(){

  $('[data-toggle="tooltip"]').tooltip();
});
</script>
</html>