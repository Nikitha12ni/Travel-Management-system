<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "rash";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html>
    <head>
    
        <title>Userview </title>
        <?php include 'links.php' ;?>
        <link rel="stylesheet" href="style.css">
        <style>
        .ad{
            
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       font-size: 150%;
                       background-color: black;
                       
  
  padding: 10px 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
}
        </style>
      
    <body>
   <div class ="ad"> <a href="admin_entry.php" target="_blank">BACK</a></div>
        <div class="main-div">
            
            <h1>VIEW BOOKINGS</h1>
            <div  class="center-div">
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>username</th>
                                <th>destination</th>
                                <th>card no</th>
                                <th>cvc </th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                        $selectquery="select USERNAME,destinsation ,CARDNO,CVC from book ";
                        $query=mysqli_query($conn,$selectquery);
                         $nums=mysqli_num_rows($query);

                         

                        while($res= mysqli_fetch_array($query))
                        {
                            ?>
                            <tr>
                            <td><?php echo $res['USERNAME'];?></td>
                            <td><?php echo $res['destinsation'];?></td>
                            <td><?php echo $res['CARDNO'];?></td>
                            <td><?php echo $res['CVC'];?></td>
                            
                        
                                             
                           </tr>
                           <?php
                        }
                        
                         ?>
                           
                        </tbody>
                    </table>


                </div>
            </div>
        </div>
        
    </body>
    <script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>
</html>