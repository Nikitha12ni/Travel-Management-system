<?php
         $servername='localhost';
         $username='root';
         $password='';
         $databasename="rash";
         $conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
     die("connection failed:".mysqli_connect_error());
}
if(isset($_POST['sendbtn']))
{    
     $name = $_POST['name'];
     $email = $_POST['email'];
     $phone_no = $_POST['phone_no'];
     $password= $_POST['password'];
     $sql_query ="insert into signup(NAME,EMAIL,PHONE_NUMBER,PASSWORD)values('$name','$email','$phone_no','$password')";
     if(mysqli_query($conn, $sql_query))
      {
        echo "Your registered successfully successfully !";
        header('location:admin_login.php');
     }
      else 
      {
        echo "Error: " . $sql . ":" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>
<html>
<head>
<link rel="icon" href="C:\Users\HP\Desktop\IMG_20211008_113158~2.jpg" type="image">
    
<link rel="stylesheet"  href="aregister.css">
<title>
signup
</title>
</head>
<body>

     <div  class="banner-area">
<form method="post" action="admin_register.php" class="submission-form">
<label for="name">
Name
</label>

<input name="name" type="text" id="name">
<label for="email">
Email
</label>
<input name="email" type="text" id="email">
<label for="phone-no">
Phone Number
</label>
<input name="phone_no" type="tel" id="phone-no">
<label for="password">
Password
</label>
<input name="password" type="text" id="password">
<input type="submit" value="Send" id="sendbtn">
</form>
</div>
</body>
</html>



