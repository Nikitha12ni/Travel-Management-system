.<?php
$servername='localhost';
$username='root';
$password='';
$databasename="rash";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>update details</title>
    </head>
    <style>
      @import url( "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css");
         .center{
                   background-color:white;
                    opacity: 0.9;
                    margin: auto;
                    width : 35%;
                    border: 1px solid black;
                    padding: 10px;
                    text-align: center
         }
         .a{
                text-align: center
         } 
         body {
                       background-image: url("images/dc.jpg");
                       background-color: #cccccc;
                       height: 300px;
                       background-repeat: no-repeat;
                       background-size: cover;
                    }
                    .c{
                      text-align: relative; 
                      position: absolute;
                       right: 100px;
                       top: 45px;
                       
                    
                     }
                     a:link, a:visited {
  background-color: black;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  text-align: relative; 
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       
}
                     a:active {
  background-color: black;}

    

                     

    
    </style>
       
    <body>
    
        <br><br>
        <div class="a">
        <h1>UPDATE </h1>
        </div>
        <div class="c">
        <img src="images/ad.gif" alt="Computer man" style="width:280px;height:280px;">
        </div>
        <br>
        <div class="center">
        <form action="" method="post">
            <?php
            $destinsation=$_GET['destinsation'];
            $showquery ="select  destinsation,noofdays ,price from admin_entry  where destinsation='$destinsation' ";
           $showdata=mysqli_query($conn,$showquery);
           $arrdata=mysqli_fetch_array($showdata);
        if(isset($_POST['submit']))
{
    $destinsation=$_GET['destinsation'];

     $destinsation=$_POST['destinsation'];
    $noofdays=$_POST['noofdays'];
     $price=$_POST['price'];
     
    
    
/*$sql_query ="insert into pharmacist(PHARMACIST_ID,FIRST_NAME,LAST_NAME,PHONE_NO,EMAIL_ID,PASSWORD) values('$PHARMACIST_ID','$FIRST_NAME',' $LAST_NAME',' $PHONE_NO','$EMAIL_ID','$PASSWORD')";*/
$query="update admin_entry set destinsation='$destinsation',noofdays='$noofdays',price='$price' where destinsation='$destinsation' ";
if(mysqli_query($conn, $query))
{
echo "values updated sucesfully";
header('location:updateanddelete.php');
}
else 
{
echo "Error: " . $sql . ":" . mysqli_error($conn);
}
mysqli_close($conn);
}



?>
               <p>destinsation <input name="destinsation" type="text" style="width:170px" placeholder="Destination" required="required" id="PHARMACIST_ID" value="<?php echo $arrdata['destinsation'];?>"/> </p> 
                <p>no of days <input name="noofdays" type="text" style="width:170px" placeholder="No of days" required="required" id="first_name" value="<?php echo $arrdata['noofdays'];?> " /></p>
                <p>price <input name="price" type="text" style="width:170px" placeholder="Price" required="required" id="last_name" value="<?php echo $arrdata['price'];?>"/></p>
               
        <p><input name="submit" type="submit" value="submit"/></p>
        
           
		</form>
        </div>
        
         
     
    
    </body>
</html>

        