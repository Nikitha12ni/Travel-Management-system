<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "rash";
$conn=mysqli_connect($servername,$username,$password,$databasename);
$destinsation=$_GET['destinsation'];
$q="DELETE from admin_entry where destinsation='$destinsation'";
mysqli_query($conn,$q);
header('location:updateanddelete.php');
?>