

<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "rash";
$conn=mysqli_connect($servername,$username,$password,$databasename);


 if(isset($_POST['done'])){

 $name = $_GET['name'];
 $destinsation= $_POST['destinsation'];
 $noofdays = $_POST['noofdays'];
 $price=$_POSt['price']
 $q = " update admin_entry set destinsation='$destinsation', noofdays='$noofdays', price='$price' where name=$name ";

 $query = mysqli_query($con,$q);

 header('location:adminupord.php');
 }

?>

<!DOCTYPE html>
<html>
<head>
 <title></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-dark">
 <h1 class="text-white text-center"> Update Operation </h1>
 </div><br>

 <label> Destination: </label>
 <input type="text" name="username" class="form-control"> <br>

 <label> noofdays </label>
 <input type="text" name="password" class="form-control"> <br>
 <label> price</label>
 <input type="text" name="password" class="form-control"> <br>

 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>

 </div>
 </form>
 </div>
</body>
</html>
     

