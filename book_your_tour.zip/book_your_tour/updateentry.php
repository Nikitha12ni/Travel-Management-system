<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "rash";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>update or delete entry</title>
    </head>
    <style>
      @import url( "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css");
         .center{
                   background-color:white;
                    opacity: 0.9;
                    margin: auto;
                    width : 35%;
                    border: 1px solid black;
                    padding: 10px;
                    text-align: center
         }
         .a{
                text-align: center
         } 
         body {
                       background-image: url("images/dc.jpg");
                       background-color: #cccccc;
                       height: 300px;
                       background-repeat: no-repeat;
                       background-size: cover;
                    }
                    .c{
                      text-align: relative; 
                      position: absolute;
                       right: 100px;
                       top: 45px;
                       
                    
                     }
                     a:link, a:visited {
  background-color: black;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  text-align: relative; 
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       
}
                     a:active {
  background-color: black;}

    

                     

    
    </style>
       
    <body>
    <a href="adminentry.php" target="_blank">BACK</a>
        <br><br>
        <div class="a">
        <h1>UPDATE PHARMACIST</h1>
        </div>
        <div class="c">
        <img src="images/ad.gif" alt="Computer man" style="width:280px;height:280px;">
        </div>
        <br>
        <div class="center">
        <form actions="updateentry.php" method="post">
            <?php
            $Username=$_GET['Username'];
            $showquery ="select  * from admin_entry where Username={$Username} ";
           $showdata=mysqli_query($conn,$showquery);
           $arrdata=mysqli_fetch_array($showdata);
        if(isset($_POST['submit']))
{  
    $Username=$_GET['Username'];
  
    $name = $_POST['name'];
    $Username = $_POST['Username'];
$destinsation = $_POST['destinsation'];
$noofdays = $_POST['noofdays'];
$price = $_POST['price'];
     
    
    
/*$sql_query ="insert into pharmacist(PHARMACIST_ID,FIRST_NAME,LAST_NAME,PHONE_NO,EMAIL_ID,PASSWORD) values('$PHARMACIST_ID','$FIRST_NAME',' $LAST_NAME',' $PHONE_NO','$EMAIL_ID','$PASSWORD')";*/
$query="update admin_entry set Username='$Username',name='$name',destinsation='$destinsation',noofdays=$noofdays, price='$price' where Username=$Username";
if(mysqli_query($conn, $query))
{
echo "values updated sucesfully";
}
else 
{
echo "Error: " . $sql . ":" . mysqli_error($conn);
}
mysqli_close($conn);
}
?>
               <p>Username <input name="Username" type="text" style="width:170px" placeholder="enter the usernmae" required="required" id="Username" value="<?php echo $arrdata['Useraname'];?>"/> </p> 
                <p>name <input name="name" type="text" style="width:170px" placeholder="Travel agency Name" required="required" id="name" value="<?php echo $arrdata['name'];?> " /></p>
                <p>Destination <input name="destination" type="text" style="width:170px" placeholder="Last Name" required="required" id="destinsation" value="<?php echo $arrdata['destinsation'];?>"/></p>
                <p >No of days <input name="noofdays" type="text" style="width:170px"placeholder="enter the no of days"  required="required" id="noofdays" value="<?php echo $arrdata['noofdays'];?>"/></p>  
	        <p >Prize <input name="price" type="text" style="width:170px" placeholder="Email" required="required" id="price" value="<?php echo $arrdata['price'];?>"/> </p> 
               
	        
          <p><input name="submit" type="submit" value="submit"/></p>
           
		</form>
        </div>
        
         
     
    
    </body>
</html>

        