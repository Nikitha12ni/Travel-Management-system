<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "rash";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}
if(isset($_POST['sendbtn']))
{    
    
    $name = $_POST['name'];
    $Username = $_POST['Username'];
$destinsation = $_POST['destinsation'];
$noofdays = $_POST['noofdays'];
$price = $_POST['price'];
$sql_query ="insert into admin_entry(name,Username,destinsation,noofdays,price)values('$name','$Username','$destinsation ','$noofdays','$price')";
if(mysqli_query($conn, $sql_query))
{
echo "You are successfully registered!";
}
else 
{
echo "Error: " . $sql . ":" . mysqli_error($conn);
}
mysqli_close($conn);
}
?>



<!DOCTYPE html>
<html>
<head>
    <title>

    </title>
    <style type="text/css">
        *{
            margin:0;
            padding:0;
        }
        body{
             background-image:url(pexels-photo-450062 (1).jpg);
             background-position:center ;
             background-size: cover;
             font-family: sans-serif;
             margin-top: 40px;
             
        }
        .bu{
            margin-left:500px;
        }
        .regform{
            width:800px;
            
            height:50px;
            background-color: rgba(3, 9, 15, 0.6);
            margin:auto;
            color:#bd3c15;
            padding:10px 0px 10px 0px;
            margin-left: 624px;
            margin-right:20px;
            border-radius:15px 15px 0px 0px;
            text-align: center;
        }
        .main{
           
            background-color: rgb(0,0,0,0.5);
            width:800px;
            margin:auto;
            }
         
         form{
             padding:10px;
         }
         #name{
             width:100%
        height:100px;
    }
        .name{
            position: relative;
left: 200px;
top:-45px;
line-height: 40px;
width: 480px;
border-radius: 6px;
padding:0 22px;
font-size:25px;

color: #555;
        }
         .company {
position: relative;
left: 200px;
top:-37px;
line-height: 40px;
width: 480px;
border-radius: 6px;
padding:0 22px;
font-size:16px;
color: #555;

}
.noofdays{
    position: relative;
left: 200px;
top:-37px;
line-height: 40px;
width: 480px;
border-radius: 6px;
padding:0 22px;
font-size:16px;
color: #555;
}
.price{
    position: relative;
left: 200px;
top:-37px;
line-height: 40px;
width: 480px;
border-radius: 6px;
padding:0 22px;
font-size:16px;
color: #555;
}
.option{
    position: relative;
left: 200px;
top:-37px;
line-height: 40px;
width: 532px;
height:40px;
border-radius: 6px;
padding:0 22px;
font-size:16px;
color: #555;
outline:none;
overflow:hidden;
}
.option option{
    font-size:20px;
}
#admin{
    margin-left: 25px;
    color:#555;
    font-size:25px;
}
.radio{
    display:inline-block;
    padding-right: 70px;
    font-size: 25px;
    margin-left: 25px;
    margin-top: 15px;
    color:#555;
}
.radio input{
    width:20px;
    height: 20px;
    border-radius: 50%;
    cursor: pointer;
    outline: none;
}

button{
    background-color: #3BAF9F;
    display:block;
    margin: 20px 0px 0px 20px;
    text-align: center;
    border-radius: 12px;
    border:2px solid #366473;
    padding: 14px 110px;
    outline: none;
    color: white;
    cursor: pointer;
    transition: 0.25px;
}
button:hover{
    
    background-color: #5390F5;
}
 .nik
 {
     margin-left: 200px;
 }       
 .nis
 {
    margin-left: 300px; 
    color:red;
 }
    .radio-one   
    {
        margin-left: 180px;
    }  
    #sendbtn
{
border:0;
background:#343050;
padding:2rem;
color:rgb(66, 30, 30);
margin:1rem 0;
width:auto;
cursor:pointer;
text-transform:uppercase;
transition:.3s background ease;
&:hover{
background:#3498DB;
}
}

    </style>
    <body>
    
        
    <div class="main-div"> 
    <div class="bu">
    
    <a href="BookYourTour.html"><button type="submit" name="up"><H4>LOGOUT</H4></button></a>
    <a href="updateanddelete.php"><button type="submit" name="up"><H4>Update or Delete</H4></button></a>
      <a href="vieworder.php"> <button type="submit" name="view"><H4>View Bookings</H4></button></div></a>
<br><br><br>
             
        <div class="regform">
            <h1>Admin Entry</h1><br><br>
        </div>
        <div class="r">
        <div class="main">
            <form method="post" action="admin_entry.php" class="submi">
                <div id="name">
                    <br><br><br><br>
                    <h2 class="name">Travel Agency Name</h2>
                    <input class="name" type="text" name="name"><br>
                     </div>
                     <h2 class="name">Username</h2>
                     <input class="company" type="text" name="Username">
             <h2 class="name">Destination</h2>
             <input class="company" type="text" name="destinsation">
             <h2 class="name">No Of Days</h2>
             <input class="noofdays" type="text" name="noofdays">
             <h2 class="name">Price</h2>
             <input class="price" type="text" name="price">
             

             <div class="nis">
                       <button type="submit" name="sendbtn">Submit</button>
                   
                    
                    </div>
                    

                    


             
            </form>
        </div>
        </div>
        <div > <a href="BookYourTour.html" target="_blank">LOGOUT</a></div>
        
    </body>
</head>
<html>