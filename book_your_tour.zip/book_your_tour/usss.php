<?php
session_start();
$servername='localhost';
$username='root';
$password='';
$databasename = "rash";
$conn=mysqli_connect($servername,$username,$password,$databasename);

if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html>
    <head>
    
        <title>Userview </title>
        <?php include 'links.php' ;?>
        <link rel="stylesheet" href="style.css">
        <style>
        .ad{
            
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       font-size: 150%;
                       background-color: black;
                       
  
  padding: 10px 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
}
        </style>
      
    <body>
   <div class ="ad"> <a href="BookYourTour.html" target="_blank">LOGOUT</a></div>
        <div class="main-div">
            
            <h1>BOOKING</h1>
            <div  class="center-div">
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>travel agency name</th>
                                <th>destination</th>
                                <th>no of days</th>
                                <th>price</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                        $selectquery="select name,destinsation ,noofdays,price from admin_entry ";
                        $query=mysqli_query($conn,$selectquery);
                         $nums=mysqli_num_rows($query);

                         

                        while($res=mysqli_fetch_array($query))
                        {
                            ?>
                            <tr>
                            <td><?php echo $res['name'];?></td>
                            <td><?php echo $res['destinsation'];?></td>
                            <td><?php echo $res['noofdays'];?></td>
                            <td><?php echo $res['price'];?></td>

                            <?php
     
     
     $_SESSION['destinsation']=$res['destinsation'];
?>
                            <td><a href="payment.php" data-toggle="tooltip" data-placement="bottom" title="Update"><i class="fa fa-edit" aria-hidden="true"></i></a></td>
                            
                                             
                           </tr>
                           <?php
                        }
                        
                         ?>
                           
                        </tbody>
                    </table>


                </div>
            </div>
        </div>
        
    </body>
    <script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>
</html>