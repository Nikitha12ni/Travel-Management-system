
<?php
session_start();
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'rash');
if(isset($_POST['login']))
{
    $Email_id= $_POST['Email'];
    $Password = $_POST['password'];
    $sql=mysqli_query($con,"SELECT * FROM signup where Email ='$Email_id' and  Password ='$Password'");
    $row  = mysqli_fetch_array($sql);
    if(is_array($row))
    {
        $_SESSION["Email"]=$row['Email_id'];
        header("Location:admin_entry.php"); 
    }
    else
    {
         echo "  <script>alert('Invalid login details')</script>";
        header("Location:admin_login.php"); 
    }
}
?>




<html>
<head>
<link rel="stylesheet" href="alogin.css">

<title>
login
</title>


</head>
<body >
<form action="admin_login.php" method="post">
<h1 style="color:rgb(0, 110, 255);
line-height:100px;"><p>Login</p></h1>
<div  class="form_input">
<input name="Email" type="text" placeholder="Username" >
</div> 
                                                                                                                                          </h1>
<div class="form_input">
<input name="password" type="password" placeholder="Password">
</div>


    <input  name="login" type="Submit" value="Login" class="btn_login" >
    <br><br>
    
Dont have an account?<br><br>
<div class="aa">
<a href="adminregister.php"><h4>Register </a></div>

</form>
</body>
</html>
