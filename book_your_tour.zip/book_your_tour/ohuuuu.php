<?php 
$host='localhost';
$user='root';
$pass='';
$db='rash';
$con=mysqli_connect($host,$user,$pass,$db);
if($con)
   echo 'connected successfully';

   $sql="insert into mytable1(name,email,phn,pass)values('$name','$email','$phone_no','$password')"
   $query=mysqli_query($con,$sql);
   if($query)
     echo 'datainserted succesfully';
     ?>
     <html>
<head>
<link rel="stylesheet"  href="aregister.css">
<title>
signup
</title>
</head>
<body>
     <div  class="banner-area">
<form class="submission-form">
<label for="name">
Name
</label>

<input type="text" id="name">
<label for="email">
Email
</label>
<input type="text" id="email">
<label for="phone_no">
Phone Number
</label>
<input type="tel" id="phone_no">
<label for="password">
Password
</label>
<input type="text" id="password">
<input type="submit" value="Send" id="sendbtn">
</form>
</div>

</body>
</html>
